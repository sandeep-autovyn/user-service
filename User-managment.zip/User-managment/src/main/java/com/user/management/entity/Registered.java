package com.user.management.entity;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Registered {
    private String date;
    private int age;
}

