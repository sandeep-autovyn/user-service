package com.user.management.service;

public interface ServiceConstant {
    String GET_RANDOM_USER ="api?results=";
}
