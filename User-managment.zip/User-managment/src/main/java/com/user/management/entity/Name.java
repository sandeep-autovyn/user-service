package com.user.management.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Name {
    private String title;
    private String first;
    private String last;
}
