package com.user.management.model;

public class City {
}
